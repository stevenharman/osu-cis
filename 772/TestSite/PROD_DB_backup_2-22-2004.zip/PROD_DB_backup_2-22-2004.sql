# phpMyAdmin SQL Dump
# version 2.5.5-pl1
# http://www.phpmyadmin.net
#
# Host: 192.168.2.201
# Generation Time: Feb 22, 2004 at 11:48 PM
# Server version: 4.0.17
# PHP Version: 4.2.3
# 
# Database : `cis772`
# 
DROP DATABASE `cis772`;
CREATE DATABASE `cis772`;
USE cis772;

# --------------------------------------------------------

#
# Table structure for table `communications`
#
# Creation: Feb 03, 2004 at 11:27 PM
# Last update: Feb 03, 2004 at 11:27 PM
#

DROP TABLE IF EXISTS `communications`;
CREATE TABLE `communications` (
  `comm_id` bigint(20) NOT NULL auto_increment,
  `comm_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `user_id` bigint(20) NOT NULL default '0',
  `message` longtext NOT NULL,
  PRIMARY KEY  (`comm_id`),
  KEY `user_id` (`user_id`),
  FULLTEXT KEY `message` (`message`)
) TYPE=MyISAM COMMENT='Communications Table' AUTO_INCREMENT=1 ;

#
# RELATIONS FOR TABLE `communications`:
#   `user_id`
#       `users` -> `user_id`
#

#
# Dumping data for table `communications`
#


# --------------------------------------------------------

#
# Table structure for table `forum_a_reply`
#
# Creation: Feb 09, 2004 at 04:54 PM
# Last update: Feb 09, 2004 at 04:54 PM
#

DROP TABLE IF EXISTS `forum_a_reply`;
CREATE TABLE `forum_a_reply` (
  `CAT_ID` int(11) NOT NULL default '0',
  `FORUM_ID` int(11) NOT NULL default '0',
  `TOPIC_ID` int(11) NOT NULL default '0',
  `REPLY_ID` int(11) NOT NULL default '0',
  `R_STATUS` smallint(6) default NULL,
  `R_MAIL` smallint(6) default NULL,
  `R_AUTHOR` int(11) default NULL,
  `R_MESSAGE` text,
  `R_DATE` varchar(14) default NULL,
  `R_IP` varchar(15) default NULL,
  `R_LAST_EDIT` varchar(14) default NULL,
  `R_LAST_EDITBY` int(11) default NULL,
  `R_SIG` smallint(6) default NULL,
  PRIMARY KEY  (`CAT_ID`,`FORUM_ID`,`TOPIC_ID`,`REPLY_ID`),
  KEY `FORUM_A_REPLY_CATFORTOPREPL` (`CAT_ID`,`FORUM_ID`,`TOPIC_ID`,`REPLY_ID`),
  KEY `FORUM_A_REPLY_REP_ID` (`REPLY_ID`),
  KEY `FORUM_A_REPLY_CAT_ID` (`CAT_ID`),
  KEY `FORUM_A_REPLY_FORUM_ID` (`FORUM_ID`),
  KEY `FORUM_A_REPLY_TOPIC_ID` (`TOPIC_ID`)
) TYPE=MyISAM;

#
# Dumping data for table `forum_a_reply`
#


# --------------------------------------------------------

#
# Table structure for table `forum_a_topics`
#
# Creation: Feb 09, 2004 at 04:54 PM
# Last update: Feb 09, 2004 at 04:54 PM
#

DROP TABLE IF EXISTS `forum_a_topics`;
CREATE TABLE `forum_a_topics` (
  `CAT_ID` int(11) NOT NULL default '0',
  `FORUM_ID` int(11) NOT NULL default '0',
  `TOPIC_ID` int(11) NOT NULL default '0',
  `T_STATUS` smallint(6) default NULL,
  `T_MAIL` smallint(6) default NULL,
  `T_SUBJECT` varchar(100) default NULL,
  `T_MESSAGE` text,
  `T_AUTHOR` int(11) default NULL,
  `T_REPLIES` int(11) default NULL,
  `T_UREPLIES` int(11) default NULL,
  `T_VIEW_COUNT` int(11) default NULL,
  `T_LAST_POST` varchar(14) default NULL,
  `T_DATE` varchar(14) default NULL,
  `T_LAST_POSTER` int(11) default NULL,
  `T_IP` varchar(15) default NULL,
  `T_LAST_POST_AUTHOR` int(11) default NULL,
  `T_LAST_POST_REPLY_ID` int(11) default NULL,
  `T_ARCHIVE_FLAG` int(11) default NULL,
  `T_LAST_EDIT` varchar(14) default NULL,
  `T_LAST_EDITBY` int(11) default NULL,
  `T_STICKY` smallint(6) default NULL,
  `T_SIG` smallint(6) default NULL,
  PRIMARY KEY  (`CAT_ID`,`FORUM_ID`,`TOPIC_ID`),
  KEY `FORUM_A_TOPIC_CATFORTOP` (`CAT_ID`,`FORUM_ID`,`TOPIC_ID`),
  KEY `FORUM_A_TOPIC_CAT_ID` (`CAT_ID`),
  KEY `FORUM_A_TOPIC_FORUM_ID` (`FORUM_ID`),
  KEY `FORUM_A_TOPIC_TOPIC_ID` (`TOPIC_ID`)
) TYPE=MyISAM;

#
# Dumping data for table `forum_a_topics`
#


# --------------------------------------------------------

#
# Table structure for table `forum_allowed_members`
#
# Creation: Feb 09, 2004 at 04:54 PM
# Last update: Feb 09, 2004 at 04:54 PM
#

DROP TABLE IF EXISTS `forum_allowed_members`;
CREATE TABLE `forum_allowed_members` (
  `MEMBER_ID` int(11) NOT NULL default '0',
  `FORUM_ID` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`MEMBER_ID`,`FORUM_ID`)
) TYPE=MyISAM;

#
# Dumping data for table `forum_allowed_members`
#


# --------------------------------------------------------

#
# Table structure for table `forum_badwords`
#
# Creation: Feb 09, 2004 at 04:54 PM
# Last update: Feb 09, 2004 at 04:54 PM
#

DROP TABLE IF EXISTS `forum_badwords`;
CREATE TABLE `forum_badwords` (
  `B_ID` int(11) NOT NULL auto_increment,
  `B_BADWORD` varchar(50) default NULL,
  `B_REPLACE` varchar(50) default NULL,
  PRIMARY KEY  (`B_ID`)
) TYPE=MyISAM AUTO_INCREMENT=6 ;

#
# Dumping data for table `forum_badwords`
#

INSERT DELAYED INTO `forum_badwords` (`B_ID`, `B_BADWORD`, `B_REPLACE`) VALUES (1, 'fuck', '****'),
(2, 'wank', '****'),
(3, 'shit', '****'),
(4, 'pussy', '*****'),
(5, 'cunt', '****');

# --------------------------------------------------------

#
# Table structure for table `forum_category`
#
# Creation: Feb 09, 2004 at 04:54 PM
# Last update: Feb 09, 2004 at 04:54 PM
#

DROP TABLE IF EXISTS `forum_category`;
CREATE TABLE `forum_category` (
  `CAT_ID` int(11) NOT NULL auto_increment,
  `CAT_STATUS` smallint(6) NOT NULL default '1',
  `CAT_NAME` varchar(100) default '',
  `CAT_MODERATION` int(11) default '0',
  `CAT_SUBSCRIPTION` int(11) default '0',
  `CAT_ORDER` int(11) default '1',
  PRIMARY KEY  (`CAT_ID`),
  KEY `FORUM_CATEGORY_CAT_ID` (`CAT_ID`),
  KEY `FORUM_CATEGORY_CAT_STATUS` (`CAT_STATUS`)
) TYPE=MyISAM AUTO_INCREMENT=3 ;

#
# Dumping data for table `forum_category`
#

INSERT DELAYED INTO `forum_category` (`CAT_ID`, `CAT_STATUS`, `CAT_NAME`, `CAT_MODERATION`, `CAT_SUBSCR�҆�ON`, `CAT_ORDER`) VALUES (2, 1, 'User Feed-back', 0, 0, 1);

# --------------------------------------------------------

#
# Table structure for table `forum_config_new`
#
# Creation: Feb 09, 2004 at 04:54 PM
# Last update: Feb 15, 2004 at 06:51 PM
#

DROP TABLE IF EXISTS `forum_config_new`;
CREATE TABLE `forum_config_new` (
  `ID` int(11) NOT NULL auto_increment,
  `C_VARIABLE` varchar(255) default NULL,
  `C_VALUE` varchar(255) default NULL,
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=156 ;

#
# Dumping data for table `forum_config_new`
#

INSERT DELAYED INTO `forum_config_new` (`ID`, `C_VARIABLE`, `C_VALUE`) VALUES (1, 'STRVERSION', 'Snitz Forums 2000 Version 3.4.04'),
(2, 'STRFORUMTITLE', 'www.BCRocket.com Forums'),
(3, 'STRCOPYRIGHT', 'www.BCRocket.com'),
(4, 'STRTITLEIMAGE', '../../images/Title1.gif'),
(5, 'STRHOMEURL', '../index.asp'),
(6, 'STRFORUMURL', 'http://www.bcrocket.com/forum/'),
(7, 'STRAUTHTYPE', 'db'),
(8, 'STRSETCOOKIETOFORUM', '0'),
(9, 'STREMAIL', '1'),
(10, 'STRUNIQUEEMAIL', '1'),
(11, 'STRMAILMODE', 'cdosys'),
(12, 'STRMAILSERVER', 'smtp-server.columbus.rr.com'),
(13, 'STRSENDER', 'harman@cis.ohio-state.edu'),
(14, 'STRDATETYPE', 'mdy'),
(15, 'STRTIMETYPE', '12'),
(16, 'STRTIMEADJUSTLOCATION', '0'),
(17, 'STRTIMEADJUST', '0'),
(18, 'STRMOVETOPICMODE', '1'),
(19, 'STRPRIVATEFORUMS', '0'),
(20, 'STRSHOWMODERATORS', '1'),
(21, 'STRSHOWRANK', '3'),
(22, 'STRHIDEEMAIL', '0'),
(23, 'STRIPLOGGING', '1'),
(24, 'STRALLOWFORUMCODE', '1'),
(25, 'STRIMGINPOSTS', '1'),
(26, 'STRALLOWHTML', '0'),
(27, 'STRSECUREADMIN', '1'),
(28, 'STRNOCOOKIES', '0'),
(29, 'STREDITEDBYDATE', '1'),
(30, 'STRHOTTOPIC', '1'),
(31, 'INTHOTTOPICNUM', '20'),
(32, 'STRHOMEPAGE', '1'),
(33, 'STRAIM', '1'),
(34, 'STRICQ', '1'),
(35, 'STRMSN', '1'),
(36, 'STRYAHOO', '1'),
(37, 'STRICONS', '1'),
(38, 'STRGFXBUTTONS', '0'),
(39, 'STRBADWORDFILTER', '1'),
(40, 'STRBADWORDS', 'fuck|wank|shit|pussy|cunt'),
(41, 'STRUSERNAMEFILTER', '0'),
(42, 'STRDEFAULTFONTFACnts<'Arial, Helvetica, sans-serif'),
(43, 'STRDEFAULTFONTSIZE', '2'),
(44, 'STRHEADERFONTSIZE', '4'),
(45, 'STRFOOTERFONTSIZE', '1'),
(46, 'STRPAGEBGCOLOR', '#FFFFFF'),
(47, 'STRDEFAULTFONTCOLOR', '#333333'),
(48, 'STRLINKCOLOR', '#990000'),
(49, 'STRLINKTEXTDECORATION', 'none'),
(50, 'STRVISITEDLINKCOLOR', '#990000'),
(51, 'STRVISITEDTEXTDECORATION', 'none'),
(52, 'STRACTIVELINKCOLOR', 'red'),
(53, 'STRHOVERFONTCOLOR', '#990000'),
(54, 'STRHOVERTEXTDECORATION', 'underline'),
(55, 'STRHEADCELLCOLOR', '#828282'),
(56, 'STRHEADFONTCOLOR', 'mintcream'),
(57, 'STRCATEGORYCELLCOLOR', '#990000'),
(58, 'STRCATEGORYFONTCOLOR', 'mintcream'),
(59, 'STRFORUMFIRSTCELLCOLOR', 'whitesmoke'),
(60, 'STRFORUMCELLCOLOR', 'whitesmoke'),
(61, 'STRALTFORUMCELLCOLOR', 'whitesmoke'),
(62, 'STRFORUMFONTCOLOR', '#333333'),
(63, 'STRFORUMLINKCOLOR', '#990000'),
(64, 'STRFORUMLINKTEXTDECORATION', 'none'),
(65, 'STRFORUMVISITEDLINKCOLOR', '#990000'),
(66, 'STRFORUMVISITEDTEXTDECORATION', 'none'),
(67, 'STRFORUMACTIVELINKCOLOR', '#990000'),
(68, 'STRFORUMACTIVETEXTDECORATION', 'none'),
(69, 'STRFORUMHOVERFONTCOLOR', '#990000'),
(70, 'STRFORUMHOVERTEXTDECORATION', 'underline'),
(71, 'STRTABLEBORDERCOLOR', '#333333'),
(72, 'STRPOPUPTABLECOLOR', 'whitesmoke'),
(73, 'STRPOPUPBORDERCOLOR', 'black'),
(74, 'STRNEWFONTCOLOR', 'blue'),
(75, 'STRHILITEFONTCOLOR', 'red'),
(76, 'STRSEARCHHILITECOLOR', 'yellow'),
(77, 'STRTOPICWIDTHLEFT', '100'),
(78, 'STRTOPICWIDTHRIGHT', '100%'),
(79, 'STRTOPICNOWRAPLEFT', '1'),
(80, 'STRTOPICNOWRAPRIGHT', '0'),
(81, 'STRRANKADMIN', 'Administrator'),
(82, 'STRRANKMOD', 'Moderator'),
(83, 'STRRANKLEVEL0', 'Starting Member'),
(84, 'STRRANKLEVEL1', 'New Member'),
(85, 'STRRANKLEVEL2', 'Junior Member'),
(86, 'STRRANKLEVEL3', 'Average Member'),
(87, 'STRRANKLEVEL4', 'Senior Member'),
(88, 'STRRANKLEVEL5', 'Advanced Member'),
(89, 'STRRANKCOLORADMIN', 'gold'),
(90, 'STRRANKCOLORMOD', 'silver'),
(91, 'STRRANKCOLOR0', 'bronze'),
(92, 'STRRANKCOLOR1', 'green'),
(93, 'STRRANKCOLOR2', 'blue'),
(94, 'STRRANKCOLOR3', 'red'),
(95, 'STRRANKCOLOR4', 'orange'),
(96, 'STRRANKCOLOR5', 'bronze'),
(97, 'INTRANKLEVEL0', '0'),
(98, 'INTRANKLEVEL1', '10'),
(99, 'INTRANKLEVEL2', '100'),
(100, 'INTRANKLEVEL3', '500'),
(101, 'INTRANKLEVEL4', '1000'),
(102, 'INTRANKLEVEL5', '2000'),
(103, 'STRSIGNATURES', '1'),
(104, 'STRDSIGNATURES', '1'),
(105, 'STRSHOWSTATISTICS', '1'),
(106, 'STRSHOWIMAGEPOWEREDBY', '0'),
(107, 'STRLOGONFORMAIL', '1'),
(108, 'STRSHOWPAGING', '1'),
(109, 'STRSHOWTOPICNAV', '1'),
(110, 'STRPAGESIZE', '15'),
(111, 'STRPAGENUMBERSIZE', '10'),
(112, 'STRFULLNAME', '1'),
(113, 'STRPICTURE', '1'),
(114, 'STRSEX', '1'),
(115, 'STRCITY', '1'),
(116, 'STRSTATE', '1'),
(117, 'STRAGE', '1'),
(118, 'STRAGEDOB', '0'),
(119, 'STRCOUNTRY', '1'),
(120, 'STROCCUPATION', '1'),
(121, 'STRFAVLINKS', '1'),
(122, 'STRBIO', '0'),
(123, 'STRHOBBIES', '0'),
(124, 'STRLNEWS', '0'),
(125, 'STRQUOTE', '0'),
(126, 'STRMARSTATUS', '1'),
(127, 'STRRECENTTOPICS', '1'),
(128, 'STRNTGROUPS', '0'),
(129, 'STRAUTOLOGON', '0'),
(130, 'STRMOVENOTIFY', '1'),
(131, 'STRSUBSCRIPTION', '0'),
(132, 'STRMODERATION', '0'),
(133, 'STRARCHIVESTATE', '1'),
(134, 'STRFLOODCHECK', '1'),
(135, 'STRFLOODCHECKTIME', '-60'),
(136, 'STREMAILVAL', '1'),
(137, 'STRPAGEBGIMAGEURL', ''),
(138, 'STRIMAGEURL', 'images/'),
(139, 'STRJUMPLASTPOST', '0'),
(140, 'STRSTICKYTOPIC', '1'),
(141, 'STRSHOWSENDTOFRIEND', '1'),
(142, 'STRSHOWPRINTERFRIENDLY', '1'),
(143, 'STRPROHIBITNEWMEMBERS', '0'),
(144, 'STRREQUIREREG', '0'),
(145, 'STRRESTRICTREG', '0'),
(146, 'STRGROUPCATEGORIES', '0'),
(147, 'STRSHOWTIMER', '1'),
(148, 'STRTIMERPHRASE', 'This page was generated in [TIMER] seconds.'),
(149, 'STRSHOWFORMATBUTTONS', '1'),
(150, 'STRSHOWSMILIESTABLE', '1'),
(151, 'STRSHOWQUICKREPLY', '1'),
(152, 'strActiveTextDecoration', 'none'),
(153, 'STRADDR1', '1'),
(154, 'STRADDR2', '1'),
(155, 'STRZIP', '1');

# --------------------------------------------------------

#
# Table structure for table `forum_forum`
#
# Creation: Feb 09, 2004 at 04:54 PM
# Last update: Feb 17, 2004 at 11:21 AM
#

DROP TABLE IF EXISTS `forum_forum`;
CREATE TABLE `forum_forum` (
  `CAT_ID` int(11) NOT NULL default '1',
  `FORUM_ID` smallint(6) NOT NULL auto_increment,
  `F_STATUS` smallint(6) default '1',
  `F_MAIL` smallint(6) default '1',
  `F_SUBJECT` varchar(100) default '',
  `F_URL` varchar(255) default '',
  `F_DESCRIPTION` text,
  `F_TOPICS` int(11) default '0',
  `F_COUNT` int(11) default '0',
  `F_LAST_POST` varchar(14) default '',
  `F_PASSWORD_NEW` varchar(255) default '',
  `F_PRIVATEFORUMS` int(11) default '0',
  `F_TYPE` smallint(6) default '0',
  `F_IP` varchar(15) default '000.000.000.000',
  `F_LAST_POST_AUTHOR` int(11) default '1',
  `F_LAST_POST_TOPIC_ID` int(11) default '0',
  `F_LAST_POST_REPLY_ID` int(11) default '0',
  `F_MODERATION` int(11) default '0',
  `F_SUBSCRIPTION` int(11) default '0',
  `F_ORDER` int(11) default '1',
  `F_DEFAULTDAYS` int(11) default '30',
  `F_COUNT_M_POSTS` smallint(6) default '1',
  `F_L_ARCHIVE` varchar(14) default '',
  `F_ARCHIVE_SCHED` int(11) default '30',
  `F_L_DELETE` varchar(14) default '',
  `F_DELETE_SCHED` int(11) default '365',
  `F_A_TOPICS` int(11) default '0',
  `F_A_COUNT` int(11) default '0',
  PRIMARY KEY  (`CAT_ID`,`FORUM_ID`),
  KEY `FORUM_FORUM_FORUM_ID` (`FORUM_ID`),
  KEY `FORUM_FORUM_CAT_ID` (`CAT_ID`)
) TYPE=MyISAM AUTO_INCREMENT=4 ;

#
# Dumping data for table `forum_forum`
#

INSERT DELAYED INTO `forum_forum` (`CAT_ID`, `FORUM_ID`, `F_STATUS`, `F_MAIL`, `F_SUBJECT`, `F_URL`, `F_DESCRIPTION`, `F_TOPICS`, `F_COUNT`, `F_LAST_POST`, `F_PASSWORD_NEW`, `F_PRIVATEFORUMS`, `F_TYPE`, `F_IP`, `F_LAST_POST_AUTHOR`, `F_LAST_POST_TOPIC_ID`, `F_LAST_POST_REPLY_ID`, `F_MODERATION`, `F_SUBSCRIPTION`, `F_ORDER`, `F_DEFAULTDAYS`, `F_COUNT_M_POSTS`, `F_L_ARCHIVE`, `F_ARCHIVE_SCHED`, `F_L_DELETE`, `F_DELETE_SCHED`, `F_A_TOPICS`, `F_A_COUNT`) VALUES (2, 2, 1, 1, 'Questions & Comments', '', 'Have some questions or comments about BCRocket.com, the forums, or anything else about the site... post them here!', 1, 1, '20040210080415', '', 0, 0, '000.000.000.000', 3, 2, 0, 0, 0, 1, 0, 1, '', 30, '', 365, 0, 0),
(2, 3, 1, 1, 'Suggestions, Bugs, and Fixes', '', 'Have some suggestions for making the site better?  Or have you found some bugs in the site?  Have some suggestions for fixes?  Let us know!', 4, 14, '20040217111247', '', 0, 0, '000.000.000.000', 3, 6, 10, 0, 0, 1, 0, 1, '', 30, '', 365, 0, 0);

# --------------------------------------------------------

#
# Table structure for table `forum_group_names`
#
# Creation: Feb 09, 2004 at 04:54 PM
# Last update: Feb 09, 2004 at 04:54 PM
#

DROP TABLE IF EXISTS `forum_group_names`;
CREATE TABLE `forum_group_names` (
  `GROUP_ID` int(11) NOT NULL auto_increment,
  `GROUP_NAME` varchar(50) default NULL,
  `GROUP_DESCRIPTION` varchar(255) default NULL,
  `GROUP_ICON` varchar(255) default NULL,
  `GROUP_IMAGE` varchar(255) default NULL,
  PRIMARY KEY  (`GROUP_ID`)
) TYPE=MyISAM AUTO_INCREMENT=3 ;

#
# Dumping data for table `forum_group_names`
#

INSERT DELAYED INTO `forum_group_names` (`GROUP_ID`, `GROUP_NAME`, `GROUP_DESCRIPTION`, `GROUP_ICON`, `GROUP_IMAGE`) VALUES (1, 'All Categories you have access to', 'All Categories you have access to', NULL, NULL),
(2, 'Default Categories', 'Default Categories', NULL, NULL);

# --------------------------------------------------------

#
# Table structure for table `forum_groups`
#
# Creation: Feb 09, 2004 at 04:54 PM
# Last update: Feb 09, 2004 at 04:54 PM
#

DROP TABLE IF EXISTS `forum_groups`;
CREATE TABLE `forum_groups` (
  `GROUP_KEY` int(11) NOT NULL auto_increment,
  `GROUP_ID` int(11) default NULL,
  `GROUP_CATID` int(11) default NULL,
  PRIMARY KEY  (`GROUP_KEY`)
) TYPE=MyISAM AUTO_INCREMENT=2 ;

#
# Dumping data for table `forum_groups`
#


# --------------------------------------------------------

#
# Table structure for table `forum_members`
#
# Creation: Feb 11, 2004 at 05:24 PM
# Last update: Feb 22, 2004 at 10:21 PM
#

DROP TABLE IF EXISTS `forum_members`;
CREATE TABLE `forum_members` (
  `MEMBER_ID` int(11) NOT NULL auto_increment,
  `M_STATUS` smallint(6) default '0',
  `M_NAME` varchar(75) default '',
  `M_USERNAME` varchar(150) default '',
  `M_PASSWORD` varchar(65) default '',
  `M_EMAIL` varchar(50) default '',
  `M_COUNTRY` varchar(50) default '',
  `M_HOMEPAGE` varchar(255) default '',
  `M_SIG` text,
  `M_VIEW_SIG` smallint(6) default '1',
  `M_SIG_DEFAULT` smallint(6) default '1',
  `M_DEFAULT_VIEW` int(11) default '1',
  `M_LEVEL` smallint(6) default '1',
  `M_AIM` varchar(150) default '',
  `M_ICQ` varchar(150) default '',
  `M_MSN` varchar(150) default '',
  `M_YAHOO` varchar(150) default '',
  `M_POSTS` int(11) default '0',
  `M_DATE` varchar(14) default '',
  `M_LASTHEREDATE` varchar(14) default '',
  `M_LASTPOSTDATE` varchar(14) default '',
  `M_TITLE` varchar(50) default '',
  `M_SUBSCRIPTION` smallint(6) default '0',
  `M_HIDE_EMAIL` smallint(6) default '0',
  `M_RECEIVE_EMAIL` smallint(6) default '1',
  `M_LAST_IP` varchar(15) default '000.000.000.000',
  `M_IP` varchar(15) default '000.000.000.000',
  `M_FIRSTNAME` varchar(100) default '',
  `M_LASTNAME` varchar(100) default '',
  `M_OCCUPATION` varchar(255) default '',
  `M_SEX` varchar(50) default '',
  `M_AGE` varchar(10) default '',
  `M_DOB` varchar(8) default '',
  `M_HOBBIES` text,
  `M_LNEWS` text,
  `M_QUOTE` text,
  `M_BIO` text,
  `M_MARSTATUS` varchar(100) default '',
  `M_LINK1` varchar(255) default '',
  `M_LINK2` varchar(255) default '',
  `M_CITY` varchar(100) default '',
  `M_STATE` varchar(100) default '',
  `M_PHOTO_URL` varchar(255) default '',
  `M_KEY` varchar(32) default '',
  `M_NEWEMAIL` varchar(50) default '',
  `M_PWKEY` varchar(32) default '',
  `M_SHA256` smallint(6) default '1',
  `M_ADDR1` varchar(50) NOT NULL default '',
  `M_ADDR2` varchar(50) default NULL,
  `M_ZIP` varchar(5) NOT NULL default '',
  `M_INV_ADMIN` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`MEMBER_ID`),
  KEY `FORUM_MEMBERS_MEMBER_ID` (`MEMBER_ID`)
) TYPE=MyISAM AUTO_INCREMENT=13 ;

#
# Dumping data for table `forum_members`
#

INSERT DELAYED INTO `forum_members` (`MEMBER_ID`, `M_STATUS`, `M_NAME`, `M_USERNAME`, `M_PASSWORD`, `M_EMAIL`, `M_COUNTRY`, `M_HOMEPAGE`, `M_SIG`, `M_VIEW_SIG`, `M_SIG_DEFAULT`, `M_DEFAULT_VIEW`, `M_LEVEL`, `M_AIM`, `M_ICQ`, `M_MSN`, `M_YAHOO`, `M_POSTS`, `M_DATE`, `M_LASTHEREDATE`, `M_LASTPOSTDATE`, `M_TITLE`, `M_SUBSCRIPTION`, `M_HIDE_EMAIL`, `M_RECEIVE_EMAIL`, `M_LAST_IP`, `M_IP`, `M_FIRSTNAME`, `M_LASTNAME`, `M_OCCUPATION`, `M_SEX`, `M_AGE`, `M_DOB`, `M_HOBBIES`, `M_LNEWS`, `M_QUOTE`, `M_BIO`, `M_MARSTATUS`, `M_LINK1`, `M_LINK2`, `M_CITY`, `M_STATE`, `M_PHOTO_URL`, `M_KEY`, `M_NEWEMAIL`, `M_PWKEY`, `M_SHA256`, `M_ADDR1`, `M_ADDR2`, `M_ZIP`, `M_INV_ADMIN`) VALUES (1, 1, 'BCRocketAdmin', 'BCRocketAdmin', '589df3f9be97ebe46ac9fcbfeff6d5cdb6e91dae2929ca63e9c36924cdb0b223', 'yourmail@server.com', '', 'http://www.bcrocket.com', ' ', 1, 1, 1, 3, '', '', '', '', 1, '20040204172914', '20040213120108', '20040204172914', 'Forum Admin', 0, 0, 0, '24.160.180.74', '000.000.000.000', '', '', '', '', '', '', NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', 'yourmail@server.com', '', 1, '', NULL, '', 1),
(3, 1, 'ussherm', '', 'dda058dac7e5f1c9b1379e3ecff7710141be6afaee442fcdbf1079d2ea47b419', 'harman.30@osu.edu', 'USA', 'http://www.buckeyeboys.com', '&gt;- 90% of being smart is knowing what you\'re dumb at -&lt;', 1, 1, 1, 3, 'ussherm', '', '', '', 7, '20040208162132', '20040222175012', '20040217111247', '', 0, 0, 1, '192.168.2.1', '192.168.2.1', 'Steve', 'Harman', 'Student', 'Male', '22', '', ' ', ' ', '"Is this thing even working?"', ' ', '', 'http://slashdot.org', '', 'Anytown', 'Ohio', 'http://www.buckeyeboys.com/piclib/jambo2003/fullimages/jambo03_091_f.jpg', '', 'harman.30@osu.edu', '', 1, '123 Some St.', '', '44444', 1),
(6, 1, 'justin', '', '102cf10b5286bad9fcfe5e275ace3ddd7dcc23931fb0ca93dc223daf9877cabd', 'jackson.814@osu.edu', 'USA', 'http://testhomepage.com', 'A test sig.', 0, 1, 1, 3, 'TestAIMName', 'testICQname', '', 'testYAHOOname', 0, '20040210035349', '20040222203002', '', '', 0, 0, 1, '24.208.173.202', '24.208.173.202', 'Justin', 'Jackson', 'Student', 'Male', '21', '', 'Some Test Hobbies', 'Some Test News', 'A cool quote', 'My test bio', 'Single', 'http://testlink1.com', 'http://testlink2.com', 'Dublin', 'OH', 'http://mypicture.com', '', 'jackson.814@osu.edu', '', 1, 'gobbledegook lane', '', '43017', 1),
(7, 1, 'Reolstan', '', 'e68444de99c5ffbfda466d2a374c28acef347eeca3a6150a001ae8b94d4d5ebb', 'eleka@columbus.rr.com', 'USA', '', '"Border relations between Canada and Mexico have never been better. " - George W. Bush Sept 24th, 2001.\r\n\r\nMakes you wonder.', 1, 1, 1, 3, 'Reolstan', '', '', '', 4, '20040212100826', '20040222170924', '20040215113205', '', 0, 0, 1, '24.93.96.98', '24.93.96.98', 'Alexander', 'Elek', 'Student', 'Male', '27', '', '', '', '', '', 'Single', '', '', 'Westerville', 'Ohio', '', '', 'eleka@columbus.rr.com', '', 1, '366 Gentlewind Dr', '', '43081', 1),
(8, 1, 'wolfycd', '', '9168e847861429230da331e23aa7983862033165c1ce3fe5f6d29a76c04c8a07', 'wolf.201@osu.edu', '', '', ' ', 1, 1, 1, 2, '', '', '', '', 4, '20040212105747', '20040222170217', '20040214115008', 'The Search Guru', 0, 0, 1, '24.160.171.235', '24.160.171.235', 'Matthew', 'Wolf', '', '', '', '', '', '', '', '', '', '', '', 'Columbus', 'OH', '', '', 'wolf.201@osu.edu', '', 1, '4664 Ralston Street', '', '43214', 1),
(9, 1, 'bcdevine', '', 'e00f9ef51a95f6e854862eed28dc0f1a68f154d9f75ddd841ab00de6ede9209b', 'bcdevine@sbcglobal.net', 'USA', '', ' ', 1, 1, 1, 2, '', '', '', '', 0, '20040212120304', '20040222123456', '', '', 0, 0, 1, '12.75.78.217', '24.93.96.98', 'Mark', 'DeVine', '', 'Male', '', '', '', '', '', '', '', '', '', 'Columbus', 'Ohio', '', '', 'bcdevine@sbcglobal.net', '', 1, 'PO Box 14357', '', '43214', 1),
(10, 1, 'testuser1', '', 'f153683d3b1aafadd5ecb6bfb96fa0d6557dddc87529d1db5e2057da173d07a4', 'thebuckeyeboys@hotmail.com', 'USA', 'http://www.buckeyeboys.com', 'I\'m the damn President!', 1, 1, 1, 1, 'AIM_Test', 'ICQ_Test', '', 'Yahoo_Text', 0, '20040212183740', '20040212183740', '', '', 0, 0, 1, '192.168.2.1', '192.168.2.1', 'George-Duba', 'Bush', 'Commander and Chief', 'Male', '99', '', '', '', 'http://pnahay.home.sprynet.com/dilbert.jpg', '', 'maried', 'http://slashdot.org', 'http://www.google.com', 'Washington', 'D.C.', '', '', '', '', 1, '1600 Penn. Ave', '', '55555', 1),
(11, 1, 'GoBucks005', '', '49452e7d75461ed1e7af8f7950b2cea723360dddb19edd1c9f6390e8ed750c2d', 'pyeager@columbus.rr.com', 'USA', 'http://yeager.no-ip.info', ' ', 1, 1, 1, 1, 'GoBucks005', '', '', '', 0, '20040213122418', '20040216052638', '', '', 0, 0, 1, '164.107.114.130', '164.107.114.127', 'Paul', 'Yeager', 'Rocket Scientist', 'Male', '22', '', '', '', '', '', 'Single', '', '', 'Columbus', 'OH', 'http://yeager.no-ip.info/msu/slides/MVC-038S.JPG', '', '', '', 1, '58 West Ninth Avenue', 'Apartment K', '43201', 1),
(12, 1, 'temp', '', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'yeager@cis.ohio-state.edu', 'USA', '', ' ', 1, 1, 1, 1, 'GoBucks005', '', '', '', 0, '20040216055437', '20040216055552', '', '', 0, 0, 1, '164.107.114.130', '164.107.114.130', 'John', 'Doe', '', '', '', '', '', '', '', '', '', '', '', 'Nowheresville', 'OH', '', '', '', '', 1, '123 Elm Street', '', '90210', 0);

# --------------------------------------------------------

#
# Table structure for table `forum_members_pending`
#
# Creation: Feb 10, 2004 at 08:54 AM
# Last update: Feb 16, 2004 at 11:21 AM
#

DROP TABLE IF EXISTS `forum_members_pending`;
CREATE TABLE `forum_members_pending` (
  `MEMBER_ID` int(11) NOT NULL auto_increment,
  `M_STATUS` smallint(6) default '0',
  `M_NAME` varchar(75) default '',
  `M_USERNAME` varchar(150) default '',
  `M_PASSWORD` varchar(65) default '',
  `M_EMAIL` varchar(50) default '',
  `M_COUNTRY` varchar(50) default '',
  `M_HOMEPAGE` varchar(255) default '',
  `M_SIG` text,
  `M_VIEW_SIG` smallint(6) default '1',
  `M_SIG_DEFAULT` smallint(6) default '1',
  `M_DEFAULT_VIEW` int(11) default '1',
  `M_LEVEL` smallint(6) default '1',
  `M_AIM` varchar(150) default '',
  `M_ICQ` varchar(150) default '',
  `M_MSN` varchar(150) default '',
  `M_YAHOO` varchar(150) default '',
  `M_POSTS` int(11) default '0',
  `M_DATE` varchar(14) default '',
  `M_LASTHEREDATE` varchar(14) default '',
  `M_LASTPOSTDATE` varchar(14) default '',
  `M_TITLE` varchar(50) default '',
  `M_SUBSCRIPTION` smallint(6) default '0',
  `M_HIDE_EMAIL` smallint(6) default '0',
  `M_RECEIVE_EMAIL` smallint(6) default '1',
  `M_LAST_IP` varchar(15) default '000.000.000.000',
  `M_IP` varchar(15) default '000.000.000.000',
  `M_FIRSTNAME` varchar(100) default '',
  `M_LASTNAME` varchar(100) default '',
  `M_OCCUPATION` varchar(255) default '',
  `M_SEX` varchar(50) default '',
  `M_AGE` varchar(10) default '',
  `M_DOB` varchar(8) default '',
  `M_HOBBIES` varchar(255) default NULL,
  `M_LNEWS` varchar(255) default NULL,
  `M_QUOTE` varchar(255) default NULL,
  `M_BIO` varchar(255) default NULL,
  `M_MARSTATUS` varchar(100) default '',
  `M_LINK1` varchar(255) default '',
  `M_LINK2` varchar(255) default '',
  `M_CITY` varchar(100) default '',
  `M_STATE` varchar(100) default '',
  `M_PHOTO_URL` varchar(255) default '',
  `M_KEY` varchar(32) default NULL,
  `M_NEWEMAIL` varchar(50) default '',
  `M_PWKEY` varchar(32) default '',
  `M_APPROVE` smallint(6) default '0',
  `M_SHA256` smallint(6) default '1',
  `M_ADDR1` varchar(50) NOT NULL default '',
  `M_ADDR2` varchar(50) default NULL,
  `M_ZIP` varchar(5) NOT NULL default '',
  PRIMARY KEY  (`MEMBER_ID`)
) TYPE=MyISAM AUTO_INCREMENT=17 ;

#
# Dumping data for table `forum_members_pending`
#


# --------------------------------------------------------

#
# Table structure for table `forum_moderator`
#
# Creation: Feb 09, 2004 at 04:54 PM
# Last update: Feb 13, 2004 at 04:21 PM
#

DROP TABLE IF EXISTS `forum_moderator`;
CREATE TABLE `forum_moderator` (
  `MOD��� int(11) NOT NULL auto_increment,
  `FORUM_ID` int(11) default '1',
  `MEMBER_ID` int(11) default '1',
  `MOD_TYPE` smallint(6) default '0',
  PRIMARY KEY  (`MOD_ID`)
) TYPE=MyISAM AUTO_INCREMENT=24 ;

#
# Dumping data for table `forum_moderator`
#

INSERT DELAYED INTO `forum_moderator` (`MOD_ID`, `FORUM_ID`, `MEMBER_ID`, `MOD_TYPE`) VALUES (23, 3, 8, 0),
(22, 3, 3, 0),
(21, 3, 7, 0),
(20, 3, 6, 0),
(19, 3, 9, 0),
(18, 2, 8, 0),
(17, 2, 3, 0),
(16, 2, 7, 0),
(15, 2, 6, 0),
(14, 2, 9, 0);

# --------------------------------------------------------

#
# Table structure for table `forum_namefilter`
#
# Creation: Feb 09, 2004 at 04:54 PM
# Last update: Feb 09, 2004 at 04:54 PM
#

DROP TABLE IF EXISTS `forum_namefilter`;
CREATE TABLE `forum_namefilter` (
  `N_ID` int(11) NOT NULL auto_increment,
  `N_NAME` varchar(75) default NULL,
  PRIMARY KEY  (`N_ID`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

#
# Dumping data for table `forum_namefilter`
#


# --------------------------------------------------------

#
# Table structure for table `forum_reply`
#
# Creation: Feb 09, 2004 at 04:54 PM
# Last update: Feb 17, 2004 at 11:39 AM
#

DROP TABLE IF EXISTS `forum_reply`;
CREATE TABLE `forum_reply` (
  `CAT_ID` int(11) NOT NULL default '1',
  `FORUM_ID` int(11) NOT NULL default '1',
  `TOPIC_ID` int(11) NOT NULL default '1',
  `REPLY_ID` int(11) NOT NULL auto_increment,
  `R_MAIL` smallint(6) default '0',
  `R_AUTHOR` int(11) default '1',
  `R_MESSAGE` text,
  `R_DATE` varchar(14) default '',
  `R_IP` varchar(15) default '000.000.000.000',
  `R_STATUS` smallint(6) default '0',
  `R_LAST_EDIT` varchar(14) default NULL,
  `R_LAST_EDITBY` int(11) default NULL,
  `R_SIG` smallint(6) default '0',
  PRIMARY KEY  (`CAT_ID`,`FORUM_ID`,`TOPIC_ID`,`REPLY_ID`),
  KEY `FORUM_REPLY_CATFORTOPREPL` (`CAT_ID`,`FORUM_ID`,`TOPIC_ID`,`REPLY_ID`),
  KEY `FORUM_REPLY_REP_ID` (`REPLY_ID`),
  KEY `FORUM_REPLY_CAT_ID` (`CAT_ID`),
  KEY `FORUM_REPLY_FORUM_ID` (`FORUM_ID`),
  KEY `FORUM_REPLY_TOPIC_ID` (`TOPIC_ID`)
) TYPE=MyISAM AUTO_INCREMENT=11 ;

#
# Dumping data for table `forum_reply`
#

INSERT DELAYED INTO `forum_reply` (`CAT_ID`, `FORUM_ID`, `TOPIC_ID`, `REPLY_ID`, `R_MAIL`, `R_AUTHOR`, `R_MESSAGE`, `R_DATE`, `R_IP`, `R_STATUS`, `R_LAST_EDIT`, `R_LAST_EDITBY`, `R_SIG`) VALUES (2, 3, 3, 1, 0, 7, 'Also, I think that before the final release, we need to make sure that the search only returns items "for sale". The public should never see items not for sale.\r\n\r\nA\r\n\r\n', '20040212102250', '24.93.96.98', 1, NULL, NULL, 1),
(2, 3, 5, 2, 0, 8, 'A couple of suggested fixes:\r\n\r\n(1) The price field in the database should have a fixed two decimal places\r\n(2) When registering, \'Sirname\' should be changed to \'Last Name\'\r\n(3) When registering, there are more required fields than indicated', '20040212140526', '24.160.171.235', 1, NULL, NULL, 1),
(2, 3, 5, 3, 0, 8, '(4) In admin section, make description textbox larger for easier viewing of full description while entry is made.', '20040213064058', '164.107.114.49', 1, NULL, NULL, 1),
(2, 3, 5, 4, 0, 8, '(5) Margaritas need to be provided at our next team meeting.', '20040213064438', '164.107.114.47', 1, NULL, NULL, 1),
(2, 3, 5, 5, 0, 3, '<blockquote id="quote"><font size="1" face="Arial, Helvetica, sans-serif" id="quote">quote:<hr height="1" noshade id="quote"><i>Originally posted by wolfycd</i>\r\n<br />(5) Margaritas need to be provided at our next team meeting.\r\n<hr height="1" noshade id="quote"></font id="quote"></blockquote id="quote">\r\n\r\nI agree... but matt, next time just edit your post and add the new items (4) & (5).  Or are you just trying to "pad your stats" and make your # of posts go up?[:)]   However, a To-Do/Wish list for the site (including forums) is very much needed.  Someone start one!  (I call, "not-it"!)', '20040213091126', '164.107.114.12', 1, NULL, NULL, 1),
(2, 3, 5, 6, 0, 7, '6) search and view inventory pages should allow item ordering by Category, Name, Qty, and Price.', '20040215113205', '24.93.96.98', 1, NULL, NULL, 1),
(2, 3, 5, 7, 0, 3, '<blockquote id="quote"><font size="1" face="Arial, Helvetica, sans-serif" id="quote">quote:<hr height="1" noshade id="quote"><i>Originally posted by Reolstan</i>\r\n<br />6) search and view inventory pages should allow item ordering by Category, Name, Qty, and Price.\r\n<hr height="1" noshade id="quote"></font id="quote"></blockquote id="quote">\r\n\r\nThis belongs under the topic "Necessary Fixes", which will be our new location for all fixes/improvements to be made before we go live.', '20040215125902', '24.160.180.74', 1, NULL, NULL, 1),
(2, 3, 6, 8, 0, 3, '- Search and view inventory pages should allow item ordering by Category, Name, Qty, and Price.  <font size="1">(this is a copy of suggestion #6 from Topic "Misc Suggestions" posted by Reolstan)</font id="size1">', '20040215130154', '24.160.180.74', 1, NULL, NULL, 1),
(2, 3, 6, 9, 0, 3, '<blockquote id="quote"><font size="1" face="Arial, Helvetica, sans-serif" id="quote">quote:<hr height="1" noshade id="quote"><i>Originally posted by wolfycd</i>\r\n[br- \'Search\' navigation button is in \'not pressed\' state while viewing results, but is in \'pressed\' state when viewing individual item details<hr height="1" noshade id="quote"></font id="quote"></blockquote id="quote">\r\n\r\nMatt, if you look at the navbar_std you\'ll see that there is a check in there to see where the user is, and display the appropriate images... you\'ve changed the names of the search_results pages, and so the checks don\'t work.  I\'ll make the appropriate changes to the navbar checks, but for future reference, thats why.', '20040215203727', '24.160.180.74', 1, NULL, NULL, 1),
(2, 3, 6, 10, 0, 3, '- Need a "<font color="red">Register Here.</font id="red">" link near the login boxes so that unregistered users don\'t have to stumble (browse) around the site until they find the register page in the forum. <font size="1">(Good call Alex)</font id="size1">\r\n\r\n[img]uploades/register_link.gif[/img]\r\n\r\n<font size="1">Sorry about the pic guys... We do need the link, but I wanted to test out the "image in post" function.</font id="size1">', '20040217111247', '130.11.184.57', 1, NULL, NULL, 1);

# --------------------------------------------------------

#
# Table structure for table `forum_subscriptions`
#
# Creation: Feb 09, 2004 at 04:54 PM
# Last update: Feb 09, 2004 at 04:54 PM
#

DROP TABLE IF EXISTS `forum_subscriptions`;
CREATE TABLE `forum_subscriptions` (
  `SUBSCRIPTION_ID` int(11) NOT NULL auto_increment,
  `MEMBER_ID` int(11) NOT NULL default '0',
  `CAT_ID` int(11) NOT NULL default '0',
  `TOPIC_ID` int(11) NOT NULL default '0',
  `FORUM_ID` int(11) NOT NULL default '0',
  KEY `FORUM_SUBSCRIPTIONS_SUB_ID` (`SUBSCRIPTION_ID`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

#
# Dumping data for table `forum_subscriptions`
#


# --------------------------------------------------------

#
# Table structure for table `forum_topics`
#
# Creation: Feb 09, 2004 at 04:54 PM
# Last update: Feb 22, 2004 at 04:51 PM
#

DROP TABLE IF EXISTS `forum_topics`;
CREATE TABLE `forum_topics` (
  `CAT_ID` int(11) NOT NULL default '1',
  `FORUM_ID` int(11) NOT NULL default '1',
  `TOPIC_ID` int(11) NOT NULL auto_increment,
  `T_STATUS` smallint(6) default '1',
  `T_MAIL` smallint(6) default '0',
  `T_SUBJECT` varchar(100) default '',
  `T_MESSAGE` text,
  `T_AUTHOR` int(11) default '1',
  `T_REPLIES` int(11) default '0',
  `T_UREPLIES` int(11) default '0',
  `T_VIEW_COUNT` int(11) default '0',
  `T_LAST_POST` varchar(14) default '',
  `T_DATE` varchar(14) default '',
  `T_LAST_POSTER` int(11) default '1',
  `T_IP` varchar(15) default '000.000.000.000',
  `T_LAST_POST_AUTHOR` int(11) default '1',
  `T_LAST_POST_REPLY_ID` int(11) default '0',
  `T_ARCHIVE_FLAG` int(11) default '1',
  `T_LAST_EDIT` varchar(14) default NULL,
  `T_LAST_EDITBY` int(11) default NULL,
  `T_STICKY` smallint(6) default '0',
  `T_SIG` smallint(6) default '0',
  PRIMARY KEY  (`CAT_ID`,`FORUM_ID`,`TOPIC_ID`),
  KEY `FORUM_TOPIC_CATF�D�P` (`CAT_ID`,`FORUM_ID`,`TOPIC_ID`),
  KEY `FORUM_TOPIC_CAT_ID` (`CAT_ID`),
  KEY `FORUM_TOPIC_FORUM_ID` (`FORUM_ID`),
  KEY `FORUM_TOPIC_TOPIC_ID` (`TOPIC_ID`)
) TYPE=MyISAM AUTO_INCREMENT=7 ;

#
# Dumping data for table `forum_topics`
#

INSERT DELAYED INTO `forum_topics` (`CAT_ID`, `FORUM_ID`, `TOPIC_ID`, `T_STATUS`, `T_MAIL`, `T_SUBJECT`, `T_MESSAGE`, `T_AUTHOR`, `T_REPLIES`, `T_UREPLIES`, `T_VIEW_COUNT`, `T_LAST_POST`, `T_DATE`, `T_LAST_POSTER`, `T_IP`, `T_LAST_POST_AUTHOR`, `T_LAST_POST_REPLY_ID`, `T_ARCHIVE_FLAG`, `T_LAST_EDIT`, `T_LAST_EDITBY`, `T_STICKY`, `T_SIG`) VALUES (2, 2, 2, 1, 0, 'The forums are working...', 'Well, the forums are up and running, and now Justin and I are trying to customize/fix/prepare them for use.  We\'ve made the necessary changes to the cis772 database tables, Justin is working on getting the forums to accept, display, update, etc... our custom user info (address, zip, etc...) and I\'m trying to integrate our site security with the forums built-in security and login functions.  For updates, be sure and check [url]http://www.buckeyeboys.com/forum/viewforum.php?f=9[/url].', 3, 0, 0, 18, '20040210080415', '20040210080415', 1, '130.11.184.57', 3, 0, 1, NULL, NULL, 0, 1),
(2, 3, 3, 1, 0, 'Search Suggestions...', 'A few suggestions:\r\n1) after a user runs a search, keep their search terms in the search bar on the search_results page so they can modify their searches without having to remember exactly what they searched on\r\n\r\n2) after a user clicks on a particular item, how about putting a link back to the search results... kind of like ebay?\r\n\r\n3) is there a wildcard? if so what is it?  how about a short explanation of how the search works (can booleans be used in the search... AND, NOT, OR, LIKE....)?', 3, 1, 0, 22, '20040212102250', '20040212054654', 1, '130.11.184.57', 7, 1, 1, NULL, NULL, 0, 1),
(2, 3, 4, 1, 0, 'Client Meeting Notes 2/12/04', 'Ok Everyone- \r\nI talked to mark today about the website, and got him started on playing around with the admin site/entering new items and everything else. Here\'s some ideas he had that we could kick around:\r\n\r\n1) FTP for image transfer might be too complex. I set his FTP client to connect to the appropriate folders on both his PC and our server, but he thought an upload utility would be helpful. I know we talked a bit about this and were having problems with the uplaod utility, but this might be something to address later.\r\n\r\n2) Mark sells a lot of items at shows and public events ( as well as ebay) and wanted to know if there was an easy way to disable the "for sale" bit for a number of items at a given time. Ex: He goes to a show and takes item x,y,z with him - rather than editing all three items individually, could we do something to let him just "uncheck" those items and disable the for sale status from a list of inventory items?\r\n\r\n3) Mark also was hoping to use the system to track where he sold some of his inventory. Since most of it is qty=1 & when he sells it, there is no more stock, he was curious to see if we could add something that keeps track of where an item was sold ( ebay, fair, antique show) and how much it was sold for (final sale price).\r\n\r\n4) He liked the "safety measures" we used - delete verification & restore function. Good job Justin.\r\n\r\nAgain, these are all just some thoughts he had while looking at the site. I asked him to play around & enter some real data into the DB, and let me know if there was anything else he ran into that was confusing or could be better, so hopefully we can get more feedback soon.\r\n\r\nA\r\n', 7, 0, 0, 13, '20040212101944', '20040212101944', 1, '24.93.96.98', 7, 0, 1, NULL, NULL, 0, 1),
(2, 3, 5, 0, 0, 'Misc Suggestions', 'Contact info for the contact page should be:\r\n\r\nDeVine Enterprises\r\nPO Box 14357\r\nColumbus, Ohio 43214\r\n614-846-1617\r\n\r\nemail: bcdevine@sbcglobal.net', 7, 6, 0, 41, '20040215125902', '20040212102529', 1, '24.93.96.98', 3, 7, 1, '20040212102551', 7, 0, 1),
(2, 3, 6, 1, 0, 'NECESSARY FIXES', '<b>Post new bugs and rem�b�fixed bugs here:</b>\r\n\r\n- Search module shouldn\'t duplicate entries if multiple pictures are linked\r\n\r\n- <s>\'Search\' navigation button is in \'not pressed\' state while viewing results, but is in \'pressed\' state when viewing individual item details</s> <font size="1">(fixed by ussherm, 2/15/2004)</font id="size1">\r\n\r\n- Price field in the database should have a fixed two decimal places\r\n\r\n- In admin section, make description textbox larger for easier viewing of full description while entry is made.', 8, 3, 0, 35, '20040217111247', '20040214115008', 1, '24.160.171.235', 3, 10, 1, '20040214115134', 8, 0, 0);

# --------------------------------------------------------

#
# Table structure for table `forum_totals`
#
# Creation: Feb 09, 2004 at 04:54 PM
# Last update: Feb 17, 2004 at 11:21 AM
#

DROP TABLE IF EXISTS `forum_totals`;
CREATE TABLE `forum_totals` (
  `COUNT_ID` smallint(6) NOT NULL auto_increment,
  `P_COUNT` int(11) default '0',
  `T_COUNT` int(11) default '0',
  `P_A_COUNT` int(11) default '0',
  `T_A_COUNT` int(11) default '0',
  `U_COUNT` int(11) default '0',
  PRIMARY KEY  (`COUNT_ID`),
  KEY `FORUM_TOTALS_COUNT_ID` (`COUNT_ID`)
) TYPE=MyISAM AUTO_INCREMENT=2 ;

#
# Dumping data for table `forum_totals`
#

INSERT DELAYED INTO `forum_totals` (`COUNT_ID`, `P_COUNT`, `T_COUNT`, `P_A_COUNT`, `T_A_COUNT`, `U_COUNT`) VALUES (1, 15, 5, 0, 0, 12);

# --------------------------------------------------------

#
# Table structure for table `item_class`
#
# Creation: Feb 12, 2004 at 02:52 PM
# Last update: Feb 22, 2004 at 11:51 PM
#

DROP TABLE IF EXISTS `item_class`;
CREATE TABLE `item_class` (
  `class_id` bigint(20) NOT NULL auto_increment,
  `class_name` varchar(40) NOT NULL default '',
  PRIMARY KEY  (`class_id`),
  UNIQUE KEY `class_name` (`class_name`)
) TYPE=MyISAM COMMENT='Item Classes' AUTO_INCREMENT=27 ;

#
# Dumping data for table `item_class`
#

INSERT DELAYED INTO `item_class` (`class_id`, `class_name`) VALUES (1, 'firefighting tools'),
(2, 'firefighting trumpets'),
(3, 'firefighting alarms'),
(4, 'tools'),
(5, 'firefighting lanterns'),
(6, 'firefighting buckets'),
(7, 'lanterns misc'),
(8, 'firefighting fire marks'),
(9, 'firefighting bells,sirens'),
(10, 'firefighting misc.'),
(11, 'Test'),
(12, 'Lighting Misc.'),
(13, 'Collectables: Advertisement'),
(14, 'Collectables: Misc.'),
(15, 'Lanterns: Dietz'),
(16, 'Firefighting: Extinguishers'),
(17, 'Lanterns: CT Ham'),
(18, 'Firefighting: Books'),
(19, 'Firefighting: Seagrave'),
(20, 'Firefighting: Insurance'),
(21, 'Firefighting: Grenades'),
(22, 'Firefighting: Literature'),
(23, 'Firefighting: Helmets'),
(24, 'Firefighting: Nozzles'),
(25, 'Firefighting: Gamewell'),
(26, 'Firefighting: Advertising');

# --------------------------------------------------------

#
# Table structure for table `item_pictures`
#
# Creation: Feb 16, 2004 at 11:30 AM
# Last update: Feb 22, 2004 at 04:16 PM
# Last check: Feb 16, 2004 at 11:30 AM
#

DROP TABLE IF EXISTS `item_pictures`;
CREATE TABLE `item_pictures` (
  `file_name` varchar(50) NOT NULL default '',
  `item_id` bigint(20) NOT NULL default '0',
  `primary_picture` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`file_name`,`item_id`),
  KEY `file_name` (`file_name`),
  KEY `item_id` (`item_id`)
) TYPE=MyISAM COMMENT='Item Picture Links';

#
# RELATIONS FOR TABLE `item_pictures`:
#   `item_id`
#       `items` -> `item_id`
#

#
# Dumping data for table `item_pictures`
#

INSERT DELAYED INTO `item_pictures` (`file_name`, `item_id`, `primary_picture`) VALUES ('P1010613.JPG', 14, 0),
('P1010633.JPG', 15, 0),
('P1010161.JPG', 16, 0),
('P1010634.JPG', 17, 0),
('P1010168.JPG', 19, 0),
('P1010635.JPG', 21, 0),
('P1010164.JPG', 23, 0),
('P1010165.JPG', 33, 0),
('P1010632.JPG', 18, 0),
('P1010629.JPG', 35, 0),
('P1010628.JPG', 44, 1),
('P1010626.JPG', 51, 1),
('P1010625.JPG', 56, 1),
('P1010615.JPG', 72, 1);

# --------------------------------------------------------

#
# Table str1086re for table `items`
#
# Creation: Feb 22, 2004 at 10:09 PM
# Last update: Feb 22, 2004 at 10:21 PM
#

DROP TABLE IF EXISTS `items`;
CREATE TABLE `items` (
  `item_id` bigint(20) NOT NULL auto_increment,
  `item_name` varchar(60) NOT NULL default '',
  `class_id` bigint(20) NOT NULL default '0',
  `item_price` decimal(10,2) default NULL,
  `for_sale` char(3) NOT NULL default 'NO',
  `active` tinyint(4) NOT NULL default '0',
  `description` longtext NOT NULL,
  `quantity` int(10) unsigned NOT NULL default '1',
  PRIMARY KEY  (`item_id`),
  FULLTEXT KEY `description` (`description`)
) TYPE=MyISAM COMMENT='Item Information' AUTO_INCREMENT=91 ;

#
# RELATIONS FOR TABLE `items`:
#   `class_id`
#       `item_class` -> `class_id`
#

#
# Dumping data for table `items`
#

INSERT DELAYED INTO `items` (`item_id`, `item_name`, `class_id`, `item_price`, `for_sale`, `active`, `description`, `quantity`) VALUES (1, 'bed key', 1, '225.00', '1', 1, '1800,s firemens bed wrench use to take apart the bed so it could be removed from a burning house usually the occupants most valuable possesion', 1),
(2, 'cairns trumpet', 2, '750.00', '1', 1, '1800,s cairns octagon 3 band nickel plated brass working trumpet.trumpet is marked cairns this is the tall one.these were used by chiefs to shout orders to the firemen.this trumpet has damage to the bell area looks to have been shoved down then straighten back out.a very heavy well built workin trumpet', 1),
(3, 'Gamewell Vitaalarm', 3, '65.00', '1', 1, 'NOS(new old stock) gamewell fire alarm in original box with instructions. These were heat dectors: just screw them in a light socket and they had an audible as well as a visual alarm a great early item in mint condition.', 1),
(4, 'iron wrench 3 sided', 4, '19.95', '1', 1, 'old iron wrench a bit rusty t shaped', 1),
(5, 'Seagrave dietz king', 5, '675.00', '1', 1, 'great nickel plated brass dietz  fire king seagrave lantern 95% of the plating is still there. the lantern has the usual dents where the apparatus hook held it. It also has a dent in the tube where the bottom of the cage hits.a very nice named dietz king.', 1),
(6, 'early  brass or copper fireman trumpet', 2, '450.00', '1', 1, 'early hand made copper or brass firemans trumpetthe trumpet is in as found condition very dirty with black soot and grunge. may clean and polish up if that is what you like.', 1),
(7, 'Early Leather Bucket', 6, '575.00', '1', 1, 'leather bucket marked H. henderson no 4 1833? it is about 15" tall 8" in diameter at the top.about 70% of the writing is still readable. The bucket is brown with yellow lettering. there are no holes, handle is there and attached.a great early bucket with great patina. These were kept by home owners to be use by the volunteers.', 1),
(8, 'Hendrickson Marine Lantern', 7, '195.00', '1', 1, 'Large 20"x9" red A.Ward Hendrickson marine galvanized tin lantern.Has large  red fresnel globe (8"x 6 1/2")in good condition. The lantern has many coats of paint (red currently but has been orange)It has asturdy hanging handle on the top and four tie down rings on the bottom of the cage. It has a brass screw in fount with a P&A wickraiser. weighs 20 lbs.', 1),
(9, 'french tin fire mark', 8, '45.00', '1', 1, 'french mutuelles A.I.M. Du Mans tin fire mark has four mounting holes in the corners. these were put on houses to indentify which houses were insured by the insurance owned fire companies.', 1),
(10, '3 1/2 " Muffin Bell', 9, '325.00', '1', 1, '# 1/2" brass muffin bell original turned wood handle works great very nice piece. These were used to alert the Volunteers that there was a fire.', 1),
(11, 'Gutta Purcha fire theme photo case', 10, '250.00', '1', 1, '1800,s firemens photo case Has firefighter holding child on staircase plus firemans scramble in center. Both sides of case are the same.There is a generic tintipe of 2 children inside.case displays well only flay is a small chip where the case snaps together.', 1),
(12, 'firefighter rattle', 10, '125.00', '1', 1, 'early double reed firemans wood rattle. Rattle has metal weighted end looks to be made of maple.6" long good condition great early piece.', 1),
(13, 'Street light with alarm box', 3, '95.00', '1', 1, '12" tall train set fire alarm street light with fire box and red lenses. turn the alarm box handle and the bell rings.powered by a D cell street sign reads Main & state St.made by theGong bell mfg. co. East Hampton Conn. These are a favorite of alarm box collectors.', 1),
(14, 'Art Deco Fire Globe', 12, '75.00', '1', 1, 'European Art Deco frame shaped globe 8" tall by 5" in diameter.  This would look great on a wall light casting its glow over your fire fighting collection.', 1),
(15, 'Early Open Flame Light', 12, '45.00', '1', 1, 'Brass wall mounted, open flame gas light.  It has been restored and mounted toan attractive oak plaque.  Great early lamp.', 1),
(16, 'Hustler Magazine Advertisement', 13, '17.00', '1', 1, 'P1010162,P1010163: 1970`s Hustler Magazine was located in Columbus, Ohio.  This is a pair of plastic coasters and a drink glass from the night club which was located in the X-rated magazine headquarters.', 3),
(17, 'Tin Fire Mark Ohio Farmers', 8, '35.00', '1', 1, 'Tin fire mark from Ohio Farmers Insurance Company has four mounting holes in each corner. 6 1/2 x 3 1/2.', 1),
(18, 'Golden Rule Hazel Cream Bottle', 14, '9.99', '1', 1, 'P1010632: Early bottle from The Citizens Wholesale Supply Co.  Columbus, Ohio.  Bottle has internal crack in neck.  6 �� x 2 � �', 1),
(19, 'Dietz Lantern Phamplet', 15, '35.00', '1', 1, 'P1010167, P1010166: Four fold for Dietz lanterns in excellent shape.  Folded, it is 5� x 8� open it is 18 �� x 8� two sided.  Shows 30 of their products.', 3),
(20, 'Dietz Marine Deck Lantern', 15, '275.00', '1', 1, 'Nickel-plated tin Dietz Marine Deck Lantern.  Has tie downs on the bell, and has original globe, excellent condition, plating in 100% excellent.  All there, all working.', 1),
(21, 'Red Comet CTC Extingusiher', 1, '65.00', '1', 1, 'Red Comet Automatic Carbon TET Extinguisher.  These Hung from the ceiling and a fusible link would melt causing a spring-loaded pin to puncture the glass globe and spray the CTC, therefore smothering the fire.', 1),
(22, 'Ham Nu-Style Lanern', 17, '75.00', '1', 1, 'Ham�s Nu-Style Lantern with red globe that was manufactured between 1912-1914.  After Dietz purchased CT Ham Co. this became the Dietz �D-Lite.� This lantern is listed is listed as rare by Anthony Hobson.  Lantern has dent in fount, otherwise lantern is in good condition.', 1),
(23, 'CTC Fire Extinguisher', 16, '45.00', '1', 1, 'Automatic Carbon TET Extinguisher.  These Hung from the ceiling and a fusible link would melt causing a spring-loaded pin to puncture the glass globe and spray the CTC, therefore smothering the fire.', 1),
(24, 'CT Ham #2 Cold Blast Milk Wagon', 17, '125.00', '1', 1, '#2 Cold Blast Milk Wagon.  This is one of largest and few Cold Blast lanterns that Ham made. What makes this lantern unique is that it has a tray under the font to catch any spilled fuel.  These were used on milk wagons and on milk houses. Has a marked Ham�s Cold Blast Globe that stands 15� tall, painted black, excellent condition.', 1),
(25, 'Fire Theme Ice Bucket', 10, '20.00', '1', 1, 'Fire Theme Ice Bucket colors are almond and black.  It has pictures of fire marks, horse drawn steamer, and fire chief with trumpet.  Excellent condition.', 1),
(26, 'Brass & Glass Sprayer', 14, '35.00', '1', 1, 'Ball jar brass sprayer made by the H. B. Hudson Co. Chicago, IL. Glass jar has a blue tint about quart size, excellent condition.', 1),
(27, 'Enjine! - Enjine! 1939', 18, '35.00', '1', 1, 'Enjine! - Enjine! 1939 � A story of fire protection.  Published by Harold Vincent Smith for the Home Insurance Company, New York, NY.  This book has lots of pictures of early firefighting collectables.  A great resource for your fire collection, many pictures are in color.  This book does have a water stain at the binding, but does not obstruct the quality of the pictures.', 1),
(28, 'Sears Catalogue Page for Dietz Lanterns', 15, '15.00', '1', 1, 'Early Sears, Roebuck Catalogue number 112 advertising Dietz Lanterns.  There are 20 lanterns on this page.  Page in excellent condition.', 1),
(29, '1940\'s Seagrave Aerial Ladder Photo', 19, '15.00', '1', 1, '1940\'s Seagrave Aerial Ladder Photo: 20� x 5 �� factory drawing in color of a 1940�s Seagrave tillered ladder, does have water stains, mounted on a wood backing.', 1),
(30, 'Texaco Fire Chief Bakelite Scotty Dog', 10, '45.00', '1', 1, 'Texaco Fire Chief Bakelite Scotty Dog was a 50th anniversary give away by the Texaco in 1952.  It is the official Bakelite Texaco Scottie Dog service station manager pin.  This is still mounted to the original cardboard holder.', 1),
(31, 'Texaco Fire Chief Glass Pump Sign', 10, '45.00', '1', 1, 'Texaco Fire Chief Glass Pump Sign: 10� x 3 �� slightly curved Fire Chief sign.  This would be a great wall hanging or desk sign for the office, excellent condition.', 1),
(32, 'Dietz Flash Light Police Lantern', 15, '100.00', '1', 1, 'Dietz Flash Light Police Lantern � has a 2 �� lens, 8� tall, made prior to 1894, font is intact, everything is working, lantern is in excellent condition.  Has carrying handles and belt clip on the rear, marked Dietz flashlight police lantern.', 1),
(33, 'CTC Fire Extinguisher', 16, '25.00', '1', 1, 'CTC Fire Extinguisher: Wall mounted carbon TET extinguisher.  These were wall-mounted holders to enable the occupant to throw it at the fire.', 1),
(34, 'Tin Box Lantern', 7, '10.00', '1', 1, 'Tin Box Lantern: Tin is painted red, lantern is 8� tall 4� square with carrying handle works fine, like new condition.', 1),
(35, 'Firemen`s Insurance Co. Sign', 20, '175.00', '1', 1, 'P1010630: Firemen&#8217;s Insurance Co. Sign: An early metal fire insurance sign from Firemen�s Insurance Co. of Newark, NJ.  Has a great graphic of fire fighter on ladder with hose in hand fighting a building fire. 20� x 14�', 2),
(36, 'Brass Working Trumpet 17"', 2, '335.00', '1', 1, 'Brass Working Trumpet: Early brass working trumpet, made by the P. Frederick Co. in Philadelphia, PA.  This trumpet is 17� tall with a 7� bell, single sash loop with red sash.  It has customary nicks and dents, a great fireman�s working trumpet.', 1),
(37, 'Brass Working Trumpet 15 1/2"', 2, '425.00', '1', 1, 'Brass Working Trumpet 15 1/2": Early fire chief�s working trumpet, two band with sash holders, has been heavily used with lots of dents, but has great patina.  A great early fire fighters collectable.', 1),
(38, 'Brass Speaking Trumpet 15"', 2, '125.00', '1', 1, 'Brass Speaking Trumpet 15" with a 6� bell end.  All brass rolled joints with carrying handle. May be fire department or early sports megaphone. Excellent condition.', 1),
(39, 'Grether Battery Lantern', 19, '295.00', '1', 1, 'Grether Battery Lantern: marked Seagrave with original leather strap and mounting bracket. Silver in color, these were used in the 20�s and 30�s. Excellent condition.', 2),
(40, 'Hardens Glass Hand Fire Grenade', 21, '175.00', '1', 1, 'Hardens Glass Hand Fire Grenade. Grenade is blue with original stopper and contents.  Is in excellent shape. Patented August 8, 1871, marked number 1. This would be a great addition to your fire collection, and a great conversation piece.', 2),
(41, 'CTC Extinguisher Marked C & O Railroad', 16, '75.00', '1', 1, 'CTC Extinguisher Marked C & O Railroad brass General Quick Aid, CTC pump fire extinguisher 17� tall with the handle. It is empty, few minor dents, this is a rare marked extinguisher.', 1),
(42, 'Dark Room Lantern', 7, '55.00', '1', 1, 'Early Dark Room Lantern, made by Rochester Optical Co. Rochester, NY, No. 3 Universal.  The size is 10� x 5�. It is all there and working, except for the red glass in the front. A large early tin dark room lantern.', 1),
(43, 'Forest Fire Motion Light by Econolite', 10, '125.00', '1', 1, 'Forest Fire Motion Light by Econolite is in working condition, has some minor dents to the outside plastic shell that do not distract from its operation or viewing.  It has pictures of deer startled by a raging forest fire.', 1),
(44, 'Westminster Fire Ins. Sign', 20, '75.00', '1', 1, 'Westminster Fire Office of London England Head office for Canada � Montreal.  Metal sign with their logo in the middle. Established 1717.  Nice sign framed 19 �: x 11 ��, has original paper backing.', 1),
(45, 'ALT CTC Fire Extinguisher', 16, '39.00', '1', 1, 'ALT CTC Fire Extinguisher, this is a plastic cased CTC grenade designed to hang from the ceiling.  It has an automatic fusible link designed to melt in the heat of the fire and a spring loaded pin breaks the glass grenade releasing the CTC as a spray and smothers the fire. Good condition, nice addition to your fire collection. ', 1),
(46, 'Kids Siren Whistle', 10, '2.00', '1', 1, 'Kids Early Siren Whistle, not recommended for children under 8 years of age.  These are worn like a ring and blow through them to emit a siren like sound. New!', 40),
(47, 'Leather Fire Bucket', 6, '55.00', '1', 1, 'Leather Fire Bucket that is 10� x 9� very early fire bucket in very poor shape.  No handle, hole in the bottom, top ring is loose, was painted but cannot be make out. ', 1),
(48, 'American Rubber Firefighting Supplies', 18, '75.00', '1', 1, 'Reproduction American Rubber Mfg. Co. Fire Hose and Supplies Book.  It has 120 pages, 7� x 5�.  A great resource for early (pre 1900) firefighting supplies.  This was copied from the original catalogue on glossy paper, spiral bound, in excellent condition.', 1),
(49, 'Dietz Fire King', 5, '175.00', '1', 1, 'Dietz Fire King Lantern with copper bottom, nickel plated tin top, has a few rust holes in the lower tubes and burner skirt, but has been polished and displays well.  It also has marked Diets fits all globe; everything is there and working.', 1),
(50, 'Fire Ball Christmas Tree Ext.', 16, '25.00', '1', 1, 'Fire Ball Christmas tree Extinguisher were mounted on Christmas trees and filled with water.  They had an automatic spring-loaded fusible link, which released by the heat of the fire smashing the glass globe releasing the water.  Made by Fire Ball Inc. Philadelphia, PA.', 1),
(51, 'Metal Burger Beer Sign', 13, '75.00', '1', 1, 'Burger Beer Metal Sign with portrait of a sexy lady inscription �Tempting�  from a Burger Beer in Cincinnati, Ohio.  The size is 24 �� x 16 ��, condition is fair.', 1),
(52, 'Midland Mutual Fire Insurance Co. Sign', 20, '65.00', '1', 1, 'Midland Mutual Fire Insurance Co. Sign is 21 �� x 14 �� wood framed brass sign.  That reads �The Midland Mutual Incorporated 1880 Fire Insurance Company Newton, Kans.� ', 1),
(53, 'Tole Firefighting Trumpet 20 1/2"', 2, '425.00', '1', 1, 'Tole Firefighting Trumpet 20 1/2".  This is a very early firefighting trumpet, appears to have been repainted, but still has traces of old red paint on the inside.  It has a few minor dents, but overall a great trumpet.', 1),
(54, 'Cairns Leather High Eagle Fire Helmet', 23, '435.00', '1', 1, 'Cairns Leather High Eagle Fire Helmet with metal No. 9 high eagle front.  It has �Chief Wiener� written on the back brim.  It is in overall good condition, but is missing the liner.  It has a sort of reddish-brown color.', 1),
(55, '30" Underwriter`s Nozzle', 24, '85.00', '1', 1, '30" Underwriter`s Nozzle.  This is a rope wound copper straight stream firefighters nozzle.  It was used mostly by fire brigades and factories and was made by Wooster Brass Co.', 2),
(56, 'Reverse Painted Glass Hartford Fire Ins.', 20, '75.00', '1', 1, 'Hartford Stag Fire Insurance Co. Reverse Painted glass Sign from Hartford Connecticut.  The size is 17� x 12�, excellent condition.', 1),
(57, 'White Star Tin Dead Flame Lantern', 12, '175.00', '1', 1, 'White Star Tin Dead Flame Lantern - 1800�s lantern with drop out font, globe is clear and unmarked.  The lantern is marked �White Star.�  I do not know if that is the White Star that owned the Titanic Cruse Ship.  Lantern is in overall OK condition.', 1),
(58, 'Short Viking Axe', 1, '125.00', '1', 1, 'Short Viking Axe � 20� long with a 10� head, which is made of aluminum.  It has a curved wood handle.  I would assume this is a parade piece.', 1),
(59, 'Liberty Tin Tube Fire Ext.', 16, '38.00', '1', 1, 'Liberty Tin Tube Fire Extinguisher � The size is 22� x 2�, extinguisher is full of dry powder.  These were hung on a hook to be jerked off the hook thus pulling the lid off and the powder was then flung at the fire there by smothering it. It has the usual dents, but is readable.', 1),
(60, 'Instantaneous Tin Tube', 16, '22.00', '1', 1, 'Instantaneous Tin Tube Fire Extinguisher � The size is 22� x 2�, extinguisher is full of dry powder.  These were hung on a hook to be jerked off the hook thus pulling the lid off and the powder was then flung at the fire there by smothering it. It has the usual dents, and is barely readable.', 1),
(61, 'Liberty Tin Tube Fire Ext. NOS', 16, '65.00', '1', 1, 'Liberty Tin Tube Fire Extinguisher NOS � The size is 22� x 2�, extinguisher is full of dry powder.  These were hung on a hook to be jerked off the hook thus pulling the lid off and the powder was then flung at the fire there by smothering it. It has a few minor scratches, otherwise in like new condition in its original holder.', 1),
(62, 'Gamewell Battery Jar', 25, '75.00', '1', 1, 'Gamewell Battery Jar � The size is 6 �� x 5 ��.  I believe this is the middle sized jar, not the common small jar.  This is in excellent condition and is marked Gamewell on both sides.', 1),
(63, 'Fire Truck Liquor Decanter', 10, '40.00', '1', 1, 'Fire Truck Liquor Decanter � �Spirit of 76� and �Mooseheart F.D� written on the side and the hood. Unfortunately it is empty, but in excellent condition.', 1),
(64, 'Thermometer Merchants Fire Ins. Co.', 20, '60.00', '1', 1, 'Thermometer Merchants Fire Insurance Company � The size is 9� diameter, it is a working thermometer that does have a few chips in the glass, and is water stained.  This is from Denver Colorado.', 1),
(65, 'Sutphen Pump Gauge', 1, '25.00', '1', 1, 'Sutphen Pump Gauge � The size is 4 �� in diameter.  Reads from �30 to 600 psi, chrome plated for panel mounting.', 1),
(66, 'Volunteer Firefighter Car Tag', 10, '20.00', '1', 1, 'Volunteer Firefighter Car Tag marked �Volunteer FD Member�, it is 3 �� square.', 1),
(67, 'Firefighters Shaving Mug', 10, '55.00', '1', 1, 'Firefighters Shaving Mug has a picture what appears to be a horse drawn wagon with four firefighters wearing their high eagle helmets.  The cup has gold trim, is in excellent condition, and is unmarked.', 1),
(68, 'Large Flashlight Lantern 7 1/2" Tall', 7, '85.00', '1', 1, 'Large Flashlight Lantern � The size is 7 1/2" x 4� with a 3 �� lens.  Overall in good condition, everything is there and working.  Has early whale oil burner, and has carrying handles and belt clip.  This is a larger and heavier police style flashlight lantern.', 1),
(69, 'Leather Fire Bucket 11"', 6, '425.00', '1', 1, 'Leather Fire Bucket � The size is 11" tall and 8 �� in diameter.  The bucket is marked �J. Averell.�  The handle is attached.  This bucket is in Excellent condition, one of the nicer buckets I have owned.', 1),
(70, 'Ladder Rubber Coated Canvas Bucket', 6, '200.00', '1', 1, 'Ladder Rubber Coated Canvas Bucket � The size is 12� tall by 10� in diameter.  These were normally carried on the side of the ladder trucks and used by the firefighters.  This bucket is in good condition; some of the rubber has worn off, especially on the handle.  The handle is attached and would be a nice addition to your fire collection.', 1),
(71, 'Firefighters Mustache Cup', 10, '55.00', '1', 1, 'Firefighters Mustache Cup � This has a fire panoply helmet, trumpet, Viking axe.  Cup is marked �Royal Crown 2804.�', 1),
(72, 'Early Tin Box Lantern', 7, '75.00', '1', 1, 'P1010617, P1010616, P1010618: Early Tin Box Lantern: A tin Box Lantern with drop out fount.  Has carrying handles on back, and a metal reflector.  The back opens to light.  It does have surface rust and pitting, but is still useable.  The size is 12� tall by 5 �� square.  Lantern is unmarked.', 4),
(73, 'Dacron Fire Hose Deck of Cards', 26, '25.00', '1', 1, 'Dacron Fire Hose Deck of Cards � This is a sealed deck from a Dacron Polyester fiber fire hose company.  Depicts a chief with fire hose wrapped around him.', 1),
(74, 'Eureka Fire Hose Paper Clip', 26, '60.00', '1', 1, 'Eureka Fire Hose Paper Clip � This is a metal paper clip depicting an eagle on top of a roll of fire hoses from the United States Rubber Co. ', 1),
(75, 'German American Fire Ins. Paper Clip', 20, '25.00', '1', 1, 'German American Fire Insurance Paper Clip � This is a aluminum paper clip from the German American Fire Insurance Company of New York.', 1),
(76, 'Paper Clip from London Assurance Corp.', 20, '35.00', '1', 1, 'Metal Paper Clip from London Assurance Corporation � This is a New York company established in 1720. ', 1),
(77, 'Notebook Eureka Fire Hose', 26, '23.00', '1', 1, 'Notebook Eureka Fire Hose � This is a pocket-sized 1950ish notebook from the Eureka Fire Hose Company, New York.', 1),
(78, 'Tin Fire Mark Continental Insurance', 8, '125.00', '1', 1, 'Tin Fire Mark Continental Insurance � The size is  7� x 3 ��.  It is inscribed Continental New York, in good condition.', 1),
(79, 'National Fire Ins. Co. Letter Opener', 20, '48.00', '1', 1, 'National Fire Ins. Co. Letter Opener � The size is 9 ��, and is nickel plated brass marked �National Fire Insurance Co. of Hartford.� ', 1),
(80, 'Lumbar Insurance Agency Letter Opener', 20, '30.00', '1', 1, 'Lumbar Insurance Agency Letter Opener � The size is 8 ��, copper, marked with � Lumber Insurance Agency Indianapolis, Ind. Fire � Automobile � Tornado.�', 1),
(81, 'Firemans Ins. Co. Paperweight', 20, '35.00', '1', 1, 'Fireman`s Ins. Co. Paperweight � The size is 3� in diameter, brass paperweight, marked with �Founded 1855 Firemen`s Insurance Company of Newark New Jersey.�', 1),
(82, 'Rhode Island Coupling Co. FD Supplies', 26, '35.00', '1', 1, 'Rhode Island Coupling Co. FD Supplies � The size is 6� x 3 ��, 15 pages of fire department supplies from Providence, RI.  Mostly hoses,  nozzles, and couplings.', 1),
(83, 'Cracker jack Fire Hose Rubber Axe', 26, '95.00', '1', 1, 'Cracker jack Fire Hose Rubber Axe � The size is 12� x 5�.  This is a advertisement piece from the American Rubber Manufacturing Company.', 1),
(84, 'Sentinel First Aid Kit', 10, '10.00', '1', 1, 'Sentinel First Aid Kit � The size is 6� x 3 �� tin first aid kit. ', 1),
(85, 'Niagara Porcelain Fire Insurance Sign', 20, '135.00', '1', 1, 'Niagara Porcelain Fire Insurance Sign � The size is 18� x 12�, white over blue, and inscribed �Established 1850 Niagara Fire Insurance company New York.�  This sign is in average condition with some serious chips around the edges.', 1),
(86, 'Newark Fire Ins. Sign', 20, '75.00', '1', 1, 'Newark Fire Insurance Sign � Aluminum sign, size is 18� x 12�, inscribed �Newark Fire Insurance Co.  Newark, N.J. Western Department, Chicago�, plus logo.', 1),
(87, 'Texaco Fire Chief Sign', 10, '35.00', '1', 1, 'Reproduction Texaco Fire Chief Sign � Porcelain over metal sign, size is 16� x 10 ��.  Very good condition dated 1986, small chip on lower right edge.', 1),
(88, 'Shawnee Fire Ins. Sign', 20, '125.00', '1', 1, 'Shawnee Fire Insurance Sign � The size is 20� x 12� tin sign inscribed �Agency The Shawnee Fire Insurance Co. of Topeka Kansas.� ', 1),
(89, 'Clipboard National Fire Group', 26, '30.00', '1', 1, 'Clipboard National Fire Group � The size is 7 �� x 4 �� brass clipboard, inscribed �The National Fire Group Western Department 50th Anniversary 1888-1938.�', 1),
(90, 'Wood Gas Alarm', 3, '30.00', '1', 1, 'Wood Gas Alarm � The size is 11� x 8�.  This is a firefigher`s style clacker, it has a single read which is made of oak.  These were used in the mines to warn the miners that there was a gas accumulation. ', 1);

# --------------------------------------------------------

#
# Table structure for table `orders`
#
# Creation: Feb 09, 2004 at 07:07 PM
# Last update: Feb 09, 2004 at 07:07 PM
#

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `order_id` bigint(20) NOT NULL auto_increment,
  `user_id` bigint(20) NOT NULL default '0',
  `order_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `shipped_date` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`order_id`)
) TYPE=MyISAM COMMENT='Order Information' AUTO_INCREMENT=1 ;

#
# RELATIONS FOR TABLE `orders`:
#   `user_id`
#       `users` -> `user_id`
#

#
# Dumping data for table `orders`
#


# --------------------------------------------------------

#
# Table structure for table `pma_column_info`
#
# Creation: Feb 03, 2004 at 11:27 PM
# Last update: Feb 09, 2004 at 07:21 PM
#

DROP TABLE IF EXISTS `pma_column_info`;
CREATE TABLE `pma_column_info` (
  `id` int(5) unsigned NOT NULL auto_increment,
  `db_name` varchar(64) NOT NULL default '',
  `table_name` varchar(64) NOT NULL default '',
  `column_name` varchar(64) NOT NULL default '',
  `comment` varchar(255) NOT NULL default '',
  `mimetype` varchar(255) NOT NULL default '',
  `transformation` varchar(255) NOT NULL default '',
  `transformation_options` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`)
) TYPE=MyISAM COMMENT='Comments for Columns' AUTO_INCREMENT=2 ;

#
# Dumping data for table `pma_column_info`
#


# --------------------------------------------------------

#
# Table structure for table `pma_history`
#
# Creation: Feb 03, 2004 at 11:27 PM
# Last update: Feb 03, 2004 at 11:27 PM
#

DROP TABLE IF EXISTS `pma_history`;
CREATE TABLE `pma_history` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `username` varchar(64) NOT NULL default '',
  `db` varchar(64) NOT NULL default '',
  `table` varchar(64) NOT NULL default '',
  `timevalue` timestamp(14) NOT NULL,
  `sqlquery` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `username` (`username`,`db`,`table`,`timevalue`)
) TYPE=MyISAM COMMENT='SQL history' AUTO_INCREMENT=1 ;

#
# Dumping data for table `pma_history`
#


# --------------------------------------------------------

#
# Table structure for table `pma_pdf_pages`
#
# Creation: Feb 03, 2004 at 11:27 PM
# Last update: Feb 03, 2004 at 11:46 PM
#

DROP TABLE IF EXISTS `pma_pdf_pages`;
CREATE TABLE `pma_pdf_pages` (
  `db_name` varchar(64) NOT NULL default '',
  `page_nr` int(10) unsigned NOT NULL auto_increment,
  `page_descr` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`page_nr`),
  KEY `db_name` (`db_name`)
) TYPE=MyISAM COMMENT='PDF Relationpages for PMA' AUTO_INCREMENT=5 ;

#
# Dumping data for table `pma_pdf_pages`
#

INSERT DELAYED INTO `pma_pdf_pages` (`db_name`, `page_nr`, `page_descr`) VALUES ('cis772', 1, 'no Description'),
('cis772', 2, 'no Description'),
('cis772', 3, 'no Description'),
('cis772', 4, 'no Description');

# --------------------------------------------------------

#
# Table structure for table `pma_relation`
#
# Creation: Feb 03, 2004 at 11:27 PM
# Last update: Feb 03, 2004 at 11:46 PM
#

DROP TABLE IF EXISTS `pma_relation`;
CREATE TABLE `pma_relation` (
  `master_db` varchar(64) NOT NULL default '',
  `master_table` varchar(64) NOT NULL default '',
  `master_field` varchar(64) NOT NULL default '',
  `foreign_db` varchar(64) NOT NULL default '',
  `foreign_table` varchar(64) NOT NULL default '',
  `foreign_field` varchar(64) NOT NULL default '',
  PRIMARY KEY  (`master_db`,`master_table`,`master_field`),
  KEY `foreign_field` (`foreign_db`,`foreign_table`)
) TYPE=MyISAM COMMENT='Relation table';

#
# Dumping data for table `pma_relation`
#

INSERT DELAYED INTO `pma_relation` (`master_db`, `master_table`, `master_field`, `foreign_db`, `foreign_table`, `foreign_field`) VALUES ('cis772', 'communications', 'user_id', 'cis772', 'users', 'user_id'),
('cis772', 'items', 'class_id', 'cis772', 'item_class', 'class_id'),
('cis772', 'item_pictures', 'item_id', 'cis772', 'items', 'item_id'),
('cis772', 'purchases', 'order_id', 'cis772', 'orders', 'order_id'),
('cis772', 'purchases', 'item_id', 'cis772', 'items', 'item_id'),
('cis772', 'orders', 'user_id', 'cis772', 'users', 'user_id');

# --------------------------------------------------------

#
# Table structure for table `pma_table_coords`
#
# Creation: Feb 03, 2004 at 11:27 PM
# Last update: Feb 03, 2004 at 11:46 PM
#

DROP TABLE IF EXISTS `pma_table_coords`;
CREATE TABLE `pma_table_coords` (
  `db_name` varchar(64) NOT NULL default '',
  `table_name` varchar(64) NOT NULL default '',
  `pdf_page_number` int(11) NOT NULL default '0',
  `x` float unsigned NOT NULL default '0',
  `y` float unsigned NOT NULL default '0',
  PRIMARY KEY  (`db_name`,`table_name`,`pdf_page_number`)
) TYPE=MyISAM COMMENT='Table coordinates for phpMyAdmin PDF output';

#
# Dumping data for table `pma_table_coords`
#

INSERT DELAYED INTO `pma_table_coords` (`db_name`, `table_name`, `pdf_page_number`, `x`, `y`) VALUES ('cis772', 'purchases', 1, '300', '246'),
('cis772', 'item_pictures', 1, '350', '300'),
('cis772', 'orders', 1, '350', '246'),
('cis772', 'communications', 1, '421.429', '340'),
('cis772', 'items', 1, '260.22', '246.695'),
('cis772', 'users', 1, '421.429', '246.695'),
('cis772', 'item_class', 1, '260.22', '300'),
('cis772', 'purchases', 2, '300', '300'),
('cis772', 'items', 2, '350', '300'),
('cis772', 'item_pictures', 2, '350', '367'),
('cis772', 'orders', 2, '260.22', '367'),
('cis772', 'communications', 2, '260.22', '246.695'),
('cis772', 'item_class', 2, '421.429', '246.695'),
('cis772', 'users', 2, '421.429', '462.715'),
('cis772', 'purchases', 3, '300', '300'),
('cis772', 'items', 3, '350', '300'),
('cis772', 'item_pictures', 3, '350', '367'),
('cis772', 'orders', 3, '260.22', '367'),
('cis772', 'communications', 3, '260.22', '246.695'),
('cis772', 'item_class', 3, '421.429', '246.695'),
('cis772', 'users', 3, '421.429', '462.715'),
('cis772', 'purchases', 4, '300', '300'),
('cis772', 'orders', 4, '350', '300'),
('cis772', 'communications', 4, '350', '367'),
('cis772', 'items', 4, '260.22', '367'),
('cis772', 'item_pictures', 4, '260.22', '246.695'),
('cis772', 'users', 4, '421.429', '246.695'),
('cis772', 'item_class', 4, '421.429', '462.715');

# --------------------------------------------------------

#
# Table structure for table `pma_table_info`
#
# Creation: Feb 03, 2004 at 11:27 PM
# Last update: Feb 03, 2004 at 11:46 PM
#

DROP TABLE IF EXISTS `pma_table_info`;
CREATE TABLE `pma_table_info` (
  `db_name` varchar(64) NOT NULL default '',
  `table_name` varchar(64) NOT NULL default '',
  `display_field` varchar(64) NOT NULL default '',
  PRIMARY KEY  (`db_name`,`table_name`)
) TYPE=MyISAM COMMENT='Table information for phpMyAdmin';

#
# Dumping data for table `pma_table_info`
#

INSERT DELAYED INTO `pma_table_info` (`db_name`, `table_name`, `display_field`) VALUES ('cis772', 'items', 'class_id');

# --------------------------------------------------------

#
# Table structure for table `purchases`
#
# Creation: Feb 03, 2004 at 11:27 PM
# Last update: Feb 03, 2004 at 11:27 PM
#

DROP TABLE IF EXISTS `purchases`;
CREATE TABLE `purchases` (
  `order_id` bigint(20) NOT NULL default '0',
  `item_id` bigint(20) NOT NULL default '0'
) TYPE=MyISAM COMMENT='Purchase Info';

#
# RELATIONS FOR TABLE `purchases`:
#   `item_id`
#       `items` -> `item_id`
#   `order_id`
#       `orders` -> `order_id`
#

#
# Dumping data for table `purchases`
#


# --------------------------------------------------------

#
# Table structure for table `users`
#
# Creation: Feb 09, 2004 at 07:10 PM
# Last update: Feb 09, 2004 at 07:10 PM
#

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` bigint(20) NOT NULL auto_increment,
  `first_name` varchar(25) NOT NULL default '',
  `last_name` varchar(30) NOT NULL default '',
  `address_1` varchar(100) NOT NULL default '',
  `address_2` varchar(100) default NULL,
  `city` varchar(25) NOT NULL default '',
  `state` char(2) NOT NULL default '',
  `zip` int(5) NOT NULL default '0',
  `username` varchar(40) NOT NULL default '',
  `password` varchar(20) NOT NULL default '',
  `email` varchar(50) NOT NULL default '',
  `admin` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`user_id`),
  UNIQUE KEY `username` (`username`)
) TYPE=MyISAM COMMENT='User Information' AUTO_INCREMENT=1 ;

#
# Dumping data for table `users`
#

